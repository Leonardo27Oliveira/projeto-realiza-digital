var aPessoas = [];
$("#salvar").on("click",function(){
	var nome = $("[name = nome]").val();
	var idade = $("[name = idade]").val();

	if (nome == "") {
		alert("Insira seu nome!");
		$("[name = nome]").focus();
		$("[name = nome]").addClass("erro");
		$("[name = nome]").removeClass("campo");
		return false;
	} else {
		$("[name = nome]").removeClass("erro");
	}

	if (idade == "" || isNaN(idade)) {
		alert("Insira sua idade (Somente Números)!");
		$("[name = idade]").focus();
		$("[name = idade]").addClass("erro");
		$("[name = nome]").removeClass("campo");
		return false;
	} else {
		$("[name = idade]").removeClass("erro");
	}
	$("#tabela").append("<tr><td>" + nome + "</td><td>" + idade + " Anos</td></tr>")
	$("[name = nome]").val("");
	$("[name = idade]").val("");
	aPessoas.push(nome);
	$("[id = total]").html(aPessoas.length);
});